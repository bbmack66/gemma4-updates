COMPLETE GEMMA4 UPDATES -- ONE FOLDER, ONE APPLY COMMAND
=====================================================

This replaces BOTH previous ZIP bundles. It contains 23 replacement/new Atlantis
files, including the automatic google/gemma-4-31B-it tokenizer loader and its
updated dependencies. No need to apply either older archive first.

1. Extract gemma4-complete-updates.zip beside your Atlantis checkout.

   parent/
     your-atlantis-checkout/
     gemma4-complete-updates/

2. Open a terminal INSIDE your Atlantis checkout and run:

   python3 ../gemma4-complete-updates/tools/apply_bundle.py --atlantis . --apply

This command deliberately replaces every listed file with the bundled version,
even if your existing version has custom edits. Before replacement it backs up
the current version under:

   Atlantis/.gemma4-compat-backups/<timestamp>/

Existing unrelated files are left alone. Identical replacements are skipped.
The command verifies bundle hashes and the target root before copying. Failed
copies trigger rollback of files already replaced. It records previously absent
files in INSTALL-RECORD.json inside the backup directory.

Nothing is committed, pushed, built, or started. Existing .rej files from earlier
patch attempts are unrelated and are not applied by this command.

To inspect without copying, omit --apply.

3. Review Source Control in VS Code (Ctrl+Shift+G). The Git diffs compare with
your last commit. To compare against previous uncommitted customizations, open
the backed-up file and installed file with VS Code's "Select for Compare" and
"Compare with Selected". New files are shown as untracked.

FILE LOCATIONS

FILES-AND-LOCATIONS.csv lists all destinations. Every file under:
  updated-files/atlantis/<path>
is installed at:
  <your-atlantis-checkout>/<path>

original-files/ contains the reviewed upstream versions, not your custom edits.
Your own pre-install files are preserved by the installer backup.

CONFIGURATION BEFORE RUNNING

The apply command changes Atlantis files only. It does not overwrite your
existing oss-crs compose file or change your API URL/key. Keep those working
settings, and incorporate the additional_env settings from config/compose.yaml.
In particular, LOCAL_LLM_ENABLED must be "1" for the bundled local-mode wrapper.

LOCAL_LLM_MODEL must be the alias accepted by your existing endpoint. The sample
uses gemma4; change that and Atlantis/oss-crs/crs.yaml's required_llms consistently
if your endpoint exposes a different alias. The tokenizer ID is separate and
defaults to google/gemma-4-31B-it regardless of the API alias.

The config example also shows the explicit opt-outs for spending checks, the
outer MLLA timer, finite MLLA invocations, and the initial generator timer. Keep
context/output budgets aligned with the ACTUAL server configuration. Existing
proxy/key/team budgets are managed on your LiteLLM server, separately.

config/litellm-gpustack.yaml is an optional model-entry example; it is not applied
automatically and does not replace authentication or other proxy configuration.

Run your normal oss-crs prepare and build-target steps after review, then run the
CRS. Rebuilding is necessary for Python dependencies, copied files, and Rust
changes. The tokenizer loader downloads/caches tokenizer assets only, not model
weights. First use needs Hugging Face access or a prepopulated cache. Supply
HF_TOKEN securely to the container only if model access requires it. Leave
LOCAL_LLM_TOKENIZER_JSON unset to use automatic loading.

The loader supports LOCAL_LLM_TOKENIZER_MODEL, LOCAL_LLM_TOKENIZER_REVISION, and
LOCAL_LLM_TOKENIZER_OFFLINE. Set the revision to match your deployed model when
needed. Text uses the actual tokenizer; the template/tool overhead buffer still
remains necessary. It never substitutes GPT counts or byte estimates on failure.

VALIDATION

See VALIDATION.txt and test-results.txt. Offline tests exercise mock requests,
tokenizer loading, failure routes, concurrency, and backed-up replacement.
Actual Hugging Face loading, dependency installation, Linux Docker/Rust builds,
GPUStack/LiteLLM execution and a long fuzzing run have not been performed here.

Per-request/context limits and finite attempts on a failing analysis remain.
They prevent one bad request from looping forever; they are distinct from cost
and overall-run ceilings. Existing Docker abort-on-container-exit behavior is
unchanged, so infrastructure failures can still stop the stack.

CLEANUP OF EARLIER BUNDLES

The Dockerfile replacement removes the obsolete local-stack-assets COPY step.
The installer backs up and removes only README.txt versions known to have been
created by these bundles; it preserves any unrecognized/custom file.
The standalone scripts/query-llm.py update has been dropped from this package
because it is not part of the app launch path. Its prior optional edit is not
reverted automatically. The local wrapper no longer creates an unused separate
summarizer client.
