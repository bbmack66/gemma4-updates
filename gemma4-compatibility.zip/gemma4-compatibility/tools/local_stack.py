"""Offline-friendly OpenAI-compatible local model policy. No model downloads."""
import asyncio
import copy
import json
import os
import re
import threading
import time
import warnings
from contextlib import asynccontextmanager
from functools import lru_cache


class LocalModelError(RuntimeError):
    pass


class ContextBudgetError(LocalModelError):
    pass


def enabled():
    return os.getenv("LOCAL_LLM_ENABLED", "0").lower() in ("1", "true", "yes")


def setting(name, default, minimum=1):
    value = int(os.getenv(name, str(default)))
    if value < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    return value


def model_name(requested):
    return os.getenv("LOCAL_LLM_MODEL", "gemma4") if enabled() else requested


def context_size():
    return setting("LOCAL_LLM_CONTEXT_TOKENS", 32768)


def output_limit(requested=None):
    cap = setting("LOCAL_LLM_MAX_OUTPUT_TOKENS", 4096)
    if cap + setting("LOCAL_LLM_TOKEN_BUFFER", 2048) >= context_size():
        raise ValueError("Local output allowance plus buffer must be smaller than context")
    if requested is not None and int(requested) < 1:
        raise ValueError("Requested output token limit must be positive")
    return min(int(requested), cap) if requested is not None else cap


@lru_cache(maxsize=4)
def _tokenizer(path):
    # Only load an explicit local file. Never use from_pretrained/network access.
    from tokenizers import Tokenizer
    return Tokenizer.from_file(path)


@lru_cache(maxsize=1)
def _warn_estimate():
    warnings.warn("No LOCAL_LLM_TOKENIZER_JSON supplied: using conservative UTF-8 byte "
                  "estimates, not the Gemma tokenizer. Supply the deployed tokenizer.json "
                  "and install tokenizers for accurate text counts.", RuntimeWarning)


def count_text(text):
    path = os.getenv("LOCAL_LLM_TOKENIZER_JSON", "")
    if path:
        try:
            return len(_tokenizer(path).encode(str(text), add_special_tokens=False).ids)
        except Exception as exc:
            raise LocalModelError(f"Cannot load local tokenizer {path}: {exc}") from exc
    _warn_estimate()
    return len(str(text).encode("utf-8"))


def count_string_tokens(text, model):
    if enabled():
        return count_text(text)
    from tokencost import count_string_tokens as provider_count
    return provider_count(text, model)


def tool_token_limit():
    return max(1, (context_size() - output_limit() - setting("LOCAL_LLM_TOKEN_BUFFER", 2048)) // 2) if enabled() else 120000


def _content(message):
    value = message.content
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, default=str)


def message_tokens(message):
    # Fixed allowance covers roles/template markers; deployment buffer covers
    # chat-template differences. tokenizer.json alone is not a chat template.
    tools = getattr(message, "tool_calls", None)
    return count_text(_content(message)) + 32 + (count_text(json.dumps(tools, default=str)) if tools else 0)


def fit_messages(messages, max_output=None, tools=()):
    messages = copy.deepcopy(messages)
    allowance = context_size() - output_limit(max_output) - setting("LOCAL_LLM_TOKEN_BUFFER", 2048)
    tool_tokens = count_text(json.dumps([
        {"name": getattr(t, "name", ""), "description": getattr(t, "description", ""),
         "schema": t.get_input_schema().model_json_schema()} for t in tools
    ], default=str)) if tools else 0
    def count():
        return sum(message_tokens(m) for m in messages) + tool_tokens
    # Drop only complete old turns. Keep system instructions and the most recent
    # user turn, including every assistant-tool/tool-result exchange within it.
    while count() > allowance:
        users = [i for i, m in enumerate(messages) if getattr(m, "type", "") in ("human", "user")]
        if len(users) < 3:
            raise ContextBudgetError(f"Current task requires {count()} input tokens/estimated units; "
                                     f"configured allowance is {allowance}. Split/reduce the source input.")
        # Preserve the initial task/source as well as the latest instruction.
        start, end = users[1], users[2]
        messages = messages[:start] + [m for m in messages[start:end]
                                     if getattr(m, "type", "") == "system"] + messages[end:]
    return messages


def parse_json(text):
    """Extract strict JSON without eval, tuple conversion, or invented fields."""
    if not isinstance(text, str):
        if isinstance(text, list):
            text = "\n".join(b.get("text", "") if isinstance(b, dict) else str(b) for b in text)
        else:
            raise ValueError("Model output is not text")
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
    fenced = re.findall(r"```(?:json)?\s*([\s\S]*?)```", text)
    candidates = fenced + [text]
    def reject_constant(value):
        raise ValueError(f"Non-JSON numeric constant: {value}")
    decoder = json.JSONDecoder(parse_constant=reject_constant)
    for candidate in candidates:
        try:
            value = json.loads(candidate, parse_constant=reject_constant)
            if isinstance(value, (dict, list)):
                return value
        except ValueError:
            pass
        match = re.search(r"[\[{]", candidate)
        if match:
            try:
                value, _ = decoder.raw_decode(candidate[match.start():])
                if isinstance(value, (dict, list)):
                    return value
            except ValueError:
                pass
    raise ValueError("No valid JSON object or array in model output")


@lru_cache(maxsize=1)
def _gate():
    return threading.BoundedSemaphore(setting("LOCAL_LLM_MAX_INFLIGHT", 2))


@asynccontextmanager
async def async_slot():
    # No loop-bound semaphore: MLLA uses multiple event loops/threads.
    gate = _gate()
    while not gate.acquire(blocking=False):
        await asyncio.sleep(0.05)
    try:
        yield
    finally:
        gate.release()


def transient(exc):
    status = getattr(exc, "status_code", None)
    name = type(exc).__name__.lower()
    return status in (408, 409, 429, 500, 502, 503, 504) or any(
        x in name for x in ("timeout", "connection", "ratelimit", "serviceunavailable"))


class LocalChatAdapter:
    """Bound requests, concurrency, context, and optional Pydantic JSON output.

    Native tools remain native tools; the deployment must support tool calling.
    Structured-only requests use prompt+strict parsing, requiring no provider
    specific JSON-schema protocol or Anthropic endpoint.
    """
    def __init__(self, client, schema=None, tools=(), max_tokens=None):
        self.client, self.schema, self.tools = client, schema, tools
        self.max_tokens = output_limit(max_tokens)

    def _prepare(self, messages, kwargs):
        from langchain_core.messages import SystemMessage, HumanMessage
        kwargs = dict(kwargs)
        kwargs["max_tokens"] = output_limit(kwargs.get("max_tokens", self.max_tokens))
        messages = [HumanMessage(content=messages)] if isinstance(messages, str) else list(messages)
        messages.insert(0, SystemMessage(content="When JSON is requested, return strict JSON: "
            "double-quoted keys, JSON arrays, lowercase true/false/null, no comments or tuples. "
            "When a tool is needed, use the provided native tool-call interface."))
        if self.schema is not None:
            schema = self.schema.model_json_schema() if hasattr(self.schema, "model_json_schema") else self.schema
            messages.insert(0, SystemMessage(content="Return only a valid JSON object matching this schema. "
                                         "No Markdown, comments, or Python tuples:\n" + json.dumps(schema)))
        return fit_messages(messages, kwargs["max_tokens"], self.tools), kwargs

    def _result(self, response):
        if getattr(response, "invalid_tool_calls", None):
            raise LocalModelError("Backend returned invalid native tool-call arguments; check its tool parser")
        if getattr(response, "response_metadata", {}).get("finish_reason") == "length":
            raise LocalModelError("Local model output was truncated; reduce the task or increase its configured output allowance")
        if self.schema is None:
            if not getattr(response, "content", None) and not getattr(response, "tool_calls", None):
                raise LocalModelError("Local model returned neither content nor native tool calls")
            return response
        value = parse_json(response.content)
        return self.schema.model_validate(value) if hasattr(self.schema, "model_validate") else value

    def invoke(self, messages, **kwargs):
        messages, kwargs = self._prepare(messages, kwargs)
        attempts = setting("LOCAL_LLM_REQUEST_ATTEMPTS", 3)
        for attempt in range(attempts):
            response = None
            try:
                with _gate():
                    response = self.client.invoke(messages, **kwargs)
                return self._result(response)
            except Exception as exc:
                if response is not None and self.schema is not None and isinstance(exc, ValueError) and attempt + 1 < attempts:
                    from langchain_core.messages import AIMessage, HumanMessage
                    messages = fit_messages(messages + [AIMessage(content=str(response.content)),
                        HumanMessage(content="The JSON failed validation. Correct the object without changing the schema: " + str(exc))],
                        kwargs["max_tokens"], self.tools)
                    continue
                if not transient(exc) or attempt + 1 == attempts:
                    raise LocalModelError(f"Local model request failed ({type(exc).__name__}): {exc}") from exc
                time.sleep(min(2 ** attempt, 8))

    async def ainvoke(self, messages, **kwargs):
        messages, kwargs = self._prepare(messages, kwargs)
        attempts = setting("LOCAL_LLM_REQUEST_ATTEMPTS", 3)
        for attempt in range(attempts):
            response = None
            try:
                async with async_slot():
                    response = await self.client.ainvoke(messages, **kwargs)
                return self._result(response)
            except Exception as exc:
                if response is not None and self.schema is not None and isinstance(exc, ValueError) and attempt + 1 < attempts:
                    from langchain_core.messages import AIMessage, HumanMessage
                    messages = fit_messages(messages + [AIMessage(content=str(response.content)),
                        HumanMessage(content="The JSON failed validation. Correct the object without changing the schema: " + str(exc))],
                        kwargs["max_tokens"], self.tools)
                    continue
                if not transient(exc) or attempt + 1 == attempts:
                    raise LocalModelError(f"Local model request failed ({type(exc).__name__}): {exc}") from exc
                await asyncio.sleep(min(2 ** attempt, 8))
