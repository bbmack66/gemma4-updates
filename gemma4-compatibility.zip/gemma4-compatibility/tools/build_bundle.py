"""Construct replacements without editing either source checkout."""
from pathlib import Path
import ast
import csv
import difflib
import hashlib
import json
import shutil

BUNDLE = Path(__file__).resolve().parents[1]
ROOT = BUNDLE.parent
ATLANTIS = ROOT / "atlantis-multilang-wo-concolic-main"
FILES = BUNDLE / "updated-files" / "atlantis"
records = []


def change(path, edits):
    original = (ATLANTIS / path).read_bytes()
    text = original.decode("utf-8").replace("\r\n", "\n")
    for before, after in edits:
        if text.count(before) != 1:
            raise RuntimeError(f"Expected exactly one match in {path}: {before[:90]!r}; found {text.count(before)}")
        text = text.replace(before, after)
    save(path, text, hashlib.sha256(original).hexdigest())


def save(path, text, original_sha256=None):
    dest = FILES / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text, encoding="utf-8", newline="\n")
    if dest.suffix == ".py":
        ast.parse(text, filename=path)
    base = ATLANTIS / path
    if original_sha256 is not None:
        snapshot = BUNDLE / "original-files" / "atlantis" / path
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(base.read_bytes())
    records.append({"repository": "atlantis", "original_relative_path": path,
                    "replacement": dest.relative_to(BUNDLE).as_posix(),
                    "original_sha256": original_sha256,
                    "original_normalized_sha256": hashlib.sha256(base.read_text().encode()).hexdigest() if original_sha256 else None,
                    "replacement_sha256": hashlib.sha256(dest.read_bytes()).hexdigest()})


helper = (BUNDLE / "tools/local_stack.py").read_text()
save("blob-gen/multilang-llm-agent/mlla/utils/local_stack.py", helper)
save("dictgen/src/utility/local_stack.py", helper)
llm = "blob-gen/multilang-llm-agent/mlla/utils/llm.py"
change(llm, [
    ('import asyncio\n', 'import asyncio\nimport os\nfrom . import local_stack\n'),
    ('def get_large_context_model_name(model: str) -> tuple[str, Optional[str]]:\n',
     'def get_large_context_model_name(model: str) -> tuple[str, Optional[str]]:\n    if local_stack.enabled():\n        return local_stack.model_name(model), None\n'),
    ('def get_rate_limit_fallback_model_name(model: str) -> Optional[str]:\n',
     'def get_rate_limit_fallback_model_name(model: str) -> Optional[str]:\n    if local_stack.enabled() or model == "o3":\n        return None\n'),
    ('    error_str = str(e)\n    if any(indicator in error_str for indicator in context_limit_error_indicators):',
     '    context_limit_error_indicators += ["context_length_exceeded", "maximum context length", "exceeds the available context", "too many tokens", "exceed_context_size"]\n    error_str = str(e).lower()\n    if any(indicator.lower() in error_str for indicator in context_limit_error_indicators):'),
    ('        if model in [ATLANTA_CHAT, ATLANTA_TOOL, ATLANTA_REASONING]:',
     '        if local_stack.enabled():\n            model = local_stack.model_name(model)\n            max_tokens = local_stack.output_limit(max_tokens)\n            prepare_large_context_model = False\n            prompt_caching = False\n            chat_model = ChatOpenAI(\n                model=model, temperature=temperature, api_key=config.api_key,\n                base_url=config.base_url, timeout=local_stack.setting("LOCAL_LLM_TIMEOUT", 300),\n                max_retries=0, max_tokens=max_tokens, callbacks=self.callbacks,\n            )\n        elif model in [ATLANTA_CHAT, ATLANTA_TOOL, ATLANTA_REASONING]:'),
    ('        if output_format is not None:\n            if model.startswith("o"):',
     '        if output_format is not None and not local_stack.enabled():\n            if model.startswith("o"):'),
    ('        self.runnable_chat_model = chat_model\n',
     '        if local_stack.enabled():\n            chat_model = local_stack.LocalChatAdapter(chat_model, schema=output_format,\n                tools=[t.get_tool() for t in tools], max_tokens=max_tokens)\n        self.runnable_chat_model = chat_model\n'),
    ('            model="gpt-5.4-mini",', '            model=local_stack.model_name("gpt-5.4-mini"),'),
    ('        # TODO: max token limit for model with tools should be different',
     '        if local_stack.enabled():\n            return local_stack.context_size() - local_stack.output_limit() - local_stack.setting("LOCAL_LLM_TOKEN_BUFFER", 2048)\n        # TODO: max token limit for model with tools should be different'),
    ('        """Returns the output token limit for the given model name."""',
     '        """Returns the output token limit for the given model name."""\n        if local_stack.enabled():\n            return local_stack.output_limit()'),
    ('        """Invoke the model with retry logic for handling exceptions."""\n        retry_attempt = 0\n\n        while True:\n            try:\n                if self.response_format is not None:\n                    return self.runnable_chat_model.invoke(',
     '        """Invoke the model with retry logic for handling exceptions."""\n        if local_stack.enabled():\n            return self.runnable_chat_model.invoke(messages, **kwargs)\n\n        retry_attempt = 0\n\n        while True:\n            try:\n                if self.response_format is not None:\n                    return self.runnable_chat_model.invoke('),
    ('        """Invoke the model with retry logic for handling exceptions."""\n\n        retry_attempt = 0\n\n        while True:\n            try:\n                if self.response_format is not None:\n                    response = await',
     '        """Invoke the model with retry logic for handling exceptions."""\n        if local_stack.enabled():\n            return await self.runnable_chat_model.ainvoke(messages, **kwargs)\n\n        retry_attempt = 0\n\n        while True:\n            try:\n                if self.response_format is not None:\n                    response = await'),
    ('                    loop = asyncio.get_running_loop()', '                    loop = asyncio.get_running_loop()'),
    ('                    event = threading.Event()\n\n                    def wake_up():\n                        event.set()\n\n                    # Schedule the wake up in the event loop\n                    loop.call_later(wait_time, wake_up)\n                    # Wait for the event (this doesn\'t block the event loop)\n                    event.wait()',
     '                    # A synchronous caller cannot wait for callbacks on the\n                    # same blocked event loop. Local mode bypasses this legacy path.\n                    time.sleep(wait_time)'),
    ('        token_cnts = []\n        for msg in messages:',
     '        token_cnts = []\n        if local_stack.enabled():\n            return [(0 if isinstance(m, RemoveMessage) else local_stack.message_tokens(m), m) for m in messages]\n        for msg in messages:'),
    ('                token_cnt = usage_metadata["total_tokens"]',
     '                token_cnt = (usage_metadata or {}).get("total_tokens", len(str(msg.content).encode("utf-8")) + len(json.dumps(msg.tool_calls)))'),
    ('        # Handle large number of messages\n        messages = self._handle_large_message_count(messages)',
     '        if local_stack.enabled():\n            # The adapter budgets tool schemas too, immediately before dispatch.\n            return local_stack.fit_messages(messages, tools=[t.get_tool() for t in self.tools])\n        # Handle large number of messages\n        messages = self._handle_large_message_count(messages)'),
])

prompt_path = "blob-gen/multilang-llm-agent/mlla/prompts/mcga.py"
prompt_text = (ATLANTIS / prompt_path).read_text()
start = prompt_text.index("<output_format>")
end = prompt_text.index("</output_format>", start) + len("</output_format>")
example = {"sink_analysis_message": "Explain the evidence for the current function", "is_vulnerable": False,
           "sink_line": "", "sink_line_number": -1, "sanitizer_candidates": [],
           "callsites": [{"name": "example_callee", "tainted_args": [0], "line_range": [[10, 5], [10, 25]], "priority": 0}]}
formatted = json.dumps(example, indent=4).replace("{", "{{").replace("}", "}}")
change(prompt_path, [(prompt_text[start:end], "<output_format>\n" + formatted + "\n</output_format>")])

change("blob-gen/multilang-llm-agent/mlla/agents/mcga.py", [
    ('from langchain_core.output_parsers import PydanticOutputParser',
     'from ..utils import local_stack\nfrom langchain_core.output_parsers import PydanticOutputParser'),
    ('        if _state is not None:\n            return _state',
     '        if _state is not None:\n            if local_stack.enabled():\n                self._local_validation_failures = getattr(self, "_local_validation_failures", 0) + 1\n                if self._local_validation_failures >= local_stack.setting("LOCAL_LLM_VALIDATION_ATTEMPTS", 3):\n                    logger.error("Skipping unresolved function after bounded validation failures: {}", self.target_fn[0])\n                    return MakeCallGraphOverallState(messages=[], step=1,\n                        resolved={"step1": True, "step2": True}, cg_root_node=None, done=False)\n            return _state\n        self._local_validation_failures = 0'),
    ('            report = parser.parse(json_contents[0])',
     '            report = (MCGASinkDetectReport.model_validate(local_stack.parse_json(content))\n                      if local_stack.enabled() else parser.parse(json_contents[0]))'),
])

change("blob-gen/multilang-llm-agent/mlla/utils/agent.py", [
    ('        responses = model_with_tools.invoke(\n            messages,\n            choice=choice,\n        )',
     '        from . import local_stack\n        try:\n            responses = model_with_tools.invoke(messages, choice=choice)\n        except local_stack.LocalModelError as exc:\n            # A failed analysis is not a vulnerability verdict. Let the owning\n            # graph handle validation/failure without terminating the CRS.\n            from langchain_core.messages import AIMessage\n            responses = messages + [AIMessage(content="LOCAL_MODEL_REQUEST_FAILED: " + str(exc))]'),
])

change("reverser/harness-reverser/tools/llm.py", [
    ('from dateutil import parser', 'from mlla.utils import local_stack\nfrom dateutil import parser'),
    ('        chat_model = ChatAnthropic(\n            model=model,\n            temperature=temperature,\n            api_key=config.api_key,\n            base_url=config.base_url,\n            max_tokens=max_tokens,\n            model_kwargs=model_kwargs,\n        )',
     '        if local_stack.enabled():\n            model = local_stack.model_name(model)\n            max_tokens = local_stack.output_limit(max_tokens)\n            chat_model = ChatOpenAI(model=model, temperature=temperature,\n                api_key=config.api_key, base_url=config.base_url, max_tokens=max_tokens,\n                timeout=local_stack.setting("LOCAL_LLM_TIMEOUT", 300), max_retries=0)\n        else:\n            chat_model = ChatAnthropic(model=model, temperature=temperature,\n                api_key=config.api_key, base_url=config.base_url, max_tokens=max_tokens,\n                model_kwargs=model_kwargs)'),
    ('        elif output_format is not None:', '        elif output_format is not None and not local_stack.enabled():'),
    ('        self.runnable_chat_model = chat_model',
     '        if local_stack.enabled():\n            chat_model = local_stack.LocalChatAdapter(chat_model, schema=output_format,\n                tools=tools or (), max_tokens=max_tokens)\n        self.runnable_chat_model = chat_model'),
    ('        if max_tokens:\n            llm = llm.bind(max_tokens=max_tokens)',
     '        if max_tokens:\n            if local_stack.enabled():\n                kwargs["max_tokens"] = local_stack.output_limit(max_tokens)\n            else:\n                llm = llm.bind(max_tokens=max_tokens)'),
])
change("reverser/harness-reverser/agents/reverser.py", [
    ('REASONING_MODEL = "claude-sonnet-4-6"', 'from mlla.utils import local_stack\n\nREASONING_MODEL = local_stack.model_name("claude-sonnet-4-6")'),
    ('CODING_MODEL = "claude-sonnet-4-6"', 'CODING_MODEL = local_stack.model_name("claude-sonnet-4-6")'),
    ('    REASONING_MODEL: 64000,\n    CODING_MODEL: 64000,',
     '    REASONING_MODEL: local_stack.output_limit(64000) if local_stack.enabled() else 64000,\n    CODING_MODEL: local_stack.output_limit(64000) if local_stack.enabled() else 64000,'),
    ('CODE_MODEL = "gpt-5.4"', 'CODE_MODEL = local_stack.model_name("gpt-5.4")'),
    ('        self.model = model', '        self.model = local_stack.model_name(model)'),
])

change("dictgen/src/utility/llm.py", [
    ('import os\n', 'import os\nimport asyncio\nfrom . import local_stack\n'),
    ('        self.llm_model = llm_model', '        self.llm_model = local_stack.model_name(llm_model)'),
    ('        client = AsyncOpenAI(base_url=self.litellm_url, api_key=self.litellm_key)',
     '        client = AsyncOpenAI(base_url=self.litellm_url, api_key=self.litellm_key, max_retries=0)'),
    ('        for attempt in range(1, max_attempts + 1):',
     '        if local_stack.enabled():\n            from langchain_core.messages import SystemMessage, HumanMessage\n            bounded = local_stack.fit_messages([SystemMessage(content=self.system_role), HumanMessage(content=message)])\n            model_input = [{"role": "system" if m.type == "system" else "user", "content": m.content} for m in bounded]\n            max_attempts = local_stack.setting("LOCAL_LLM_REQUEST_ATTEMPTS", 3)\n        try:\n            return await self._request(client, model_input, max_attempts)\n        finally:\n            await client.close()\n\n    async def _request(self, client, model_input, max_attempts):\n        for attempt in range(1, max_attempts + 1):'),
    ('                response = await client.chat.completions.create(\n                    model=self.llm_model,\n                    messages=model_input,\n                    temperature=self.temperature,\n                    timeout=self.timeout,\n                )\n                return str(response.choices[0].message.content)',
     '                options = dict(model=self.llm_model, messages=model_input,\n                    temperature=self.temperature, timeout=self.timeout)\n                if local_stack.enabled():\n                    options["max_tokens"] = local_stack.output_limit()\n                    async with local_stack.async_slot():\n                        response = await client.chat.completions.create(**options)\n                else:\n                    response = await client.chat.completions.create(**options)\n                if response.choices[0].finish_reason == "length":\n                    raise InferenceException("Dictionary output truncated")\n                content = response.choices[0].message.content\n                if not content:\n                    raise InferenceException("Empty dictionary response")\n                return content'),
    ('            time.sleep(30)',
     '                if local_stack.enabled() and not local_stack.transient(e):\n                    raise InferenceException(str(e)) from e\n            if attempt < max_attempts:\n                await asyncio.sleep(min(2 ** attempt, 30))'),
])

# Remove implicit time/iteration and spending ceilings only when explicitly using
# local mode; retain per-request/context/work-item bounds.
change("blob-gen/multilang-llm-agent/mlla/main.py", [
    ('    generator_timeout = int(os.environ.get("BGA_GENERATOR_STANDALONE_TIMEOUT", "1000"))',
     '    from .utils import local_stack\n    generator_timeout = int(os.environ.get("BGA_GENERATOR_STANDALONE_TIMEOUT", "0" if local_stack.enabled() else "1000"))'),
])
change("uniafl/src/msa/stage/mlla.rs", [
    ('        let cmd = format!(\n            "timeout 3h python -m mlla.main',
     '        let duration: u64 = std::env::var("MLLA_PROCESS_TIMEOUT").unwrap_or_else(|_| "10800".to_string())\n            .parse().expect("MLLA_PROCESS_TIMEOUT must be an integer number of seconds");\n        let prefix = if duration == 0 { String::new() } else { format!("timeout {} ", duration) };\n        let cmd = format!(\n            "{}python -m mlla.main'),
    ('            &self.harness_name,\n            self.mlla_workdir.display(),',
     '            prefix,\n            &self.harness_name,\n            self.mlla_workdir.display(),'),
    ('                counter: Arc::new(RwLock::new(StageCounter {',
     '                counter: Arc::new(RwLock::new(StageCounter {'),
    ('                    remain: config.mlla_iter_cnt - 1,',
     '                    remain: if std::env::var("MLLA_UNLIMITED_ITERATIONS").as_deref() == Ok("1") {\n                        u32::MAX\n                    } else { config.mlla_iter_cnt.saturating_sub(1) },'),
    ('        Command::new("bash")\n            .args(["-c", cmd.as_str()])',
     '        let result = Command::new("bash")\n            .args(["-c", cmd.as_str()])'),
    ('            .output()\n            .ok();\n    }\n\n    fn get_bcda_result',
     '            .output();\n        match result {\n            Ok(output) if !output.status.success() => eprintln!("MLLA worker {} exited: {} (see MLLA log)", worker_idx, output.status),\n            Err(error) => eprintln!("MLLA worker {} failed to launch: {}", worker_idx, error),\n            _ => {}\n        }\n    }\n\n    fn get_bcda_result'),
])
change("uniafl/src/msa/stage/stage.rs", [
    ('        counter.remain -= 1;', '        if counter.remain != u32::MAX {\n            counter.remain -= 1;\n        }'),
])
change("libs/libCRS/libCRS/crs.py", [
    ('    async def async_in_llm_limit(self):\n        spend = await self.async_llm_total_spend()',
     '    async def async_in_llm_limit(self):\n        if os.getenv("LOCAL_LLM_DISABLE_COST_LIMIT", "0") == "1":\n            return True\n        spend = await self.async_llm_total_spend()'),
])

crs_path = "oss-crs/crs.yaml"
crs_text = (ATLANTIS / crs_path).read_text()
change(crs_path, [(crs_text[crs_text.index("required_llms:"):], "required_llms:\n  - gemma4\n")])
change("oss-crs/dockerfiles/multilang-base-runner.Dockerfile", [
    ('COPY ./dictgen /home/crs/dictgen/',
     'COPY ./dictgen /home/crs/dictgen/\n# Optional deployed Gemma tokenizer.json; no network download.\nCOPY ./local-stack-assets /opt/local-stack-assets'),
])
save("local-stack-assets/README.txt", "Optional: put the tokenizer.json from the exact deployed Gemma model here before prepare.\nThen set LOCAL_LLM_TOKENIZER_JSON=/opt/local-stack-assets/tokenizer.json in compose additional_env.\nThis file is a container build input; do not put API keys here.\n")
change("scripts/query-llm.py", [
    ('    llm = ChatOpenAI(\n        api_key=api_key, base_url=endpoint, model=model\n    ).with_structured_output(Output)\n    return llm',
     '    from mlla.utils import local_stack\n    if local_stack.enabled():\n        return local_stack.LocalChatAdapter(ChatOpenAI(api_key=api_key,\n            base_url=endpoint, model=local_stack.model_name(model),\n            max_tokens=local_stack.output_limit(), max_retries=0,\n            timeout=local_stack.setting("LOCAL_LLM_TIMEOUT", 300)), schema=Output)\n    return ChatOpenAI(api_key=api_key, base_url=endpoint, model=model).with_structured_output(Output)'),
])

for name in ("astgrep", "codeindexer", "ripgrep"):
    tool_path = f"blob-gen/multilang-llm-agent/mlla/utils/llm_tools/{name}.py"
    source = (ATLANTIS / tool_path).read_text()
    edits = [('from tokencost import count_string_tokens', 'from ..local_stack import count_string_tokens, tool_token_limit')]
    # astgrep contains two independent result-size checks.
    updated = source.replace('if token_cnt > 120000:', 'if token_cnt > tool_token_limit():')
    updated = updated.replace(edits[0][0], edits[0][1])
    change(tool_path, [(source, updated)])

change("blob-gen/multilang-llm-agent/mlla/agents/cgpa.py", [
    ('        res_dict = parser.invoke(json_str[0])',
     '        from ..utils import local_stack\n        res_dict = local_stack.parse_json(response.content) if local_stack.enabled() else parser.invoke(json_str[0])'),
])
change("blob-gen/multilang-llm-agent/mlla/agents/bcga.py", [
    ('                output = output_parser.parse(response[-1].content)',
     '                from ..utils import local_stack\n                output = (DiffFilterOutput.model_validate(local_stack.parse_json(response[-1].content))\n                          if local_stack.enabled() else output_parser.parse(response[-1].content))'),
])
change("blob-gen/multilang-llm-agent/mlla/agents/cpua.py", [
    ('            ["understand_reflection", TOOL_MODEL],', '            ["understand_reflection", TOOL_MODEL, "finalize"],'),
    ('            ["get_file_path", TOOL_MODEL],', '            ["get_file_path", TOOL_MODEL, "finalize"],'),
    ('        if len(state["api_dict"]) != 0:',
     '        if state.get("resolved", {}).get(-1):\n            return "finalize"\n        if len(state["api_dict"]) != 0:'),
    ('        if len(state["reflection_api_dict"]) != 0 or len(state["messages"]) == 0:',
     '        if state.get("resolved", {}).get(-1):\n            return "finalize"\n        if len(state["reflection_api_dict"]) != 0 or len(state["messages"]) == 0:'),
    ('            api_dict = parser.invoke(json_contents[0])',
     '            from ..utils import local_stack\n            api_dict = local_stack.parse_json(content) if local_stack.enabled() else parser.invoke(json_contents[0])\n            if not isinstance(api_dict, dict) or (not api_dict and not is_reflection):\n                raise ValueError("Expected a nonempty harness analysis object")'),
    ('            harness_dict = parser.invoke(content)',
     '            from ..utils import local_stack\n            harness_dict = local_stack.parse_json(content) if local_stack.enabled() else parser.invoke(content)'),
    ('    async def understand_harnesses(',
     '    def _local_retry_exhausted(self, state):\n        from ..utils import local_stack\n        if not local_stack.enabled():\n            return False\n        key = state.get("step", 0)\n        counts = getattr(self, "_local_validation_counts", {})\n        counts[key] = counts.get(key, 0) + 1\n        self._local_validation_counts = counts\n        if counts[key] < local_stack.setting("LOCAL_LLM_VALIDATION_ATTEMPTS", 3):\n            return False\n        logger.error("Skipping unresolved harness analysis after bounded validation failures")\n        state["resolved"] = {-1: True}\n        return True\n\n    async def understand_harnesses('),
    ('                api_dict = await self._understand_harnesses_verifier(last_message)\n            except Exception as e:',
     '                api_dict = await self._understand_harnesses_verifier(last_message)\n            except Exception as e:\n                if self._local_retry_exhausted(state):\n                    return state'),
    ('            except Exception as e:\n                logger.error(f"Error: {e}")\n\n                msg = CPUA_ERROR.format(error=e)',
     '            except Exception as e:\n                if self._local_retry_exhausted(state):\n                    return state\n                logger.error(f"Error: {e}")\n\n                msg = CPUA_ERROR.format(error=e)'),
    ('        cgs: dict[str, list[CG]] = {}', '        if not functions_set:\n            return state\n        cgs: dict[str, list[CG]] = {}'),
])

(BUNDLE / "manifest.json").write_text(json.dumps(records, indent=2) + "\n")
with (BUNDLE / "FILES-AND-LOCATIONS.csv").open("w", newline="", encoding="utf-8") as handle:
    writer = csv.writer(handle)
    writer.writerow(["bundle_file", "destination_relative_to_atlantis", "operation"])
    for entry in records:
        writer.writerow([entry["replacement"], entry["original_relative_path"], "replace" if entry["original_sha256"] else "add"])
diffs = []
for entry in records:
    path = entry["original_relative_path"]
    old = (ATLANTIS / path).read_text() if entry["original_sha256"] else ""
    new = (BUNDLE / entry["replacement"]).read_text()
    diffs.extend(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                    fromfile="a/" + path if old else "/dev/null", tofile="b/" + path))
(BUNDLE / "atlantis.patch").write_text("".join(diffs), encoding="utf-8", newline="\n")
print(f"Created {len(records)} replacement/new files; original checkouts unchanged")
