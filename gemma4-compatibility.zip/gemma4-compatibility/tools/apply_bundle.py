"""Checked, idempotent installer. Defaults to inspection; --apply writes files."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys
import uuid

BUNDLE = Path(__file__).resolve().parents[1]


def digest(data, normalized=False):
    if normalized:
        data = data.decode("utf-8").replace("\r\n", "\n").encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def inside(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError(f"Path outside selected root: {relative}")
    return path


def install(root, apply=False):
    root = root.resolve()
    if not root.is_dir():
        raise ValueError(f"Atlantis directory does not exist: {root}")
    entries = json.loads((BUNDLE / "manifest.json").read_text())
    pending, conflicts = [], []
    for entry in entries:
        source = inside(BUNDLE, entry["replacement"])
        if digest(source.read_bytes()) != entry["replacement_sha256"]:
            raise ValueError(f"Bundle file failed integrity check: {source}")
        dest = inside(root, entry["original_relative_path"])
        if dest.exists():
            current = dest.read_bytes()
            if digest(current, True) == digest(source.read_bytes(), True):
                continue
            if entry["original_sha256"] is None or (
                digest(current) != entry["original_sha256"] and
                digest(current, True) != entry["original_normalized_sha256"]
            ):
                conflicts.append(entry["original_relative_path"])
                continue
        elif entry["original_sha256"] is not None:
            conflicts.append(entry["original_relative_path"] + " (missing)")
            continue
        pending.append((source, dest, entry["original_relative_path"]))
    if conflicts:
        raise ValueError("Existing changes detected; nothing copied. Merge atlantis.patch instead:\n  " + "\n  ".join(conflicts))
    print(f"{len(pending)} files ready; {len(entries) - len(pending)} already match the bundle")
    if not apply or not pending:
        return len(pending)
    backup = root / ".gemma4-compat-backups" / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8])
    backup.mkdir(parents=True)
    applied = []
    try:
        for source, dest, relative in pending:
            existed = dest.exists()
            if existed:
                previous = inside(backup, relative)
                previous.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dest, previous)
            dest.parent.mkdir(parents=True, exist_ok=True)
            temporary = dest.with_name(dest.name + ".gemma4-" + uuid.uuid4().hex + ".tmp")
            try:
                temporary.write_bytes(source.read_bytes())
                if existed:
                    shutil.copymode(dest, temporary)
                temporary.replace(dest)
            finally:
                if temporary.exists(): temporary.unlink()
            applied.append((dest, relative, existed))
    except Exception:
        for dest, relative, existed in reversed(applied):
            if existed: shutil.copy2(inside(backup, relative), dest)
            else: dest.unlink()
        raise
    print(f"Installed {len(applied)} files; originals backed up under {backup}")
    return len(applied)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--atlantis", type=Path, required=True)
    parser.add_argument("--apply", action="store_true", help="Apply only if every existing file matches its reviewed base")
    args = parser.parse_args()
    try: install(args.atlantis, args.apply)
    except (ValueError, OSError) as exc:
        print(exc, file=sys.stderr)
        sys.exit(1)
