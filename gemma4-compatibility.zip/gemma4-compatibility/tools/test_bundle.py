"""Offline regression checks; no inference services or third-party installs."""
import asyncio
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "updated-files/atlantis/blob-gen/multilang-llm-agent/mlla/utils/local_stack.py"
spec = importlib.util.spec_from_file_location("local_stack", MODULE)
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)


class Message:
    type = "base"
    def __init__(self, content="", **kwargs):
        self.content = content
        self.tool_calls = kwargs.get("tool_calls", [])
        self.response_metadata = kwargs.get("response_metadata", {})


class HumanMessage(Message):
    type = "human"


class SystemMessage(Message):
    type = "system"


class AIMessage(Message):
    type = "ai"


class ToolMessage(Message):
    type = "tool"


messages_module = types.ModuleType("langchain_core.messages")
for cls in (HumanMessage, SystemMessage, AIMessage, ToolMessage):
    setattr(messages_module, cls.__name__, cls)
sys.modules["langchain_core.messages"] = messages_module


class Schema:
    @classmethod
    def model_json_schema(cls):
        return {"type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"]}
    @classmethod
    def model_validate(cls, obj):
        if not isinstance(obj, dict) or type(obj.get("ok")) is not bool:
            raise ValueError("ok must be boolean")
        return obj


class Client:
    def __init__(self, results=None):
        self.results = iter(results or [AIMessage('{"ok": true}')])
        self.calls = []
    def invoke(self, messages, **kwargs):
        self.calls.append((messages, kwargs))
        result = next(self.results)
        if isinstance(result, Exception):
            raise result
        return result
    async def ainvoke(self, messages, **kwargs):
        return self.invoke(messages, **kwargs)


class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {
            "LOCAL_LLM_ENABLED": "1", "LOCAL_LLM_MODEL": "gemma4",
            "LOCAL_LLM_CONTEXT_TOKENS": "8192", "LOCAL_LLM_MAX_OUTPUT_TOKENS": "512",
            "LOCAL_LLM_TOKEN_BUFFER": "256", "LOCAL_LLM_MAX_INFLIGHT": "2",
            "LOCAL_LLM_REQUEST_ATTEMPTS": "3", "LOCAL_LLM_TOKENIZER_JSON": "",
        })
        self.env.start()
        policy._gate.cache_clear()
    def tearDown(self):
        self.env.stop()

    def test_routes_all_aliases_locally(self):
        for name in ("claude-sonnet-4-6", "gpt-5.4", "o3", "gemini-3.1-pro-preview"):
            self.assertEqual(policy.model_name(name), "gemma4")

    def test_output_cap_and_invalid_configuration(self):
        self.assertEqual(policy.output_limit(64000), 512)
        self.assertEqual(policy.output_limit(100), 100)
        with self.assertRaises(ValueError): policy.output_limit(0)
        with patch.dict(os.environ, {"LOCAL_LLM_MAX_OUTPUT_TOKENS": "8192"}):
            with self.assertRaises(ValueError): policy.output_limit()

    def test_no_tokenizer_uses_utf8_bytes(self):
        self.assertEqual(policy.count_text("abc😀"), 7)

    def test_explicit_bad_tokenizer_fails_instead_of_silent_fallback(self):
        with patch.dict(os.environ, {"LOCAL_LLM_TOKENIZER_JSON": "missing.json"}):
            with self.assertRaises(policy.LocalModelError): policy.count_text("x")

    def test_local_tokenizer_is_used(self):
        class Tokenizer:
            @staticmethod
            def from_file(path):
                self.assertEqual(path, "deployed.json")
                return types.SimpleNamespace(encode=lambda text, add_special_tokens: types.SimpleNamespace(ids=[1, 2]))
        with patch.dict(sys.modules, {"tokenizers": types.SimpleNamespace(Tokenizer=Tokenizer)}), patch.dict(os.environ, {"LOCAL_LLM_TOKENIZER_JSON": "deployed.json"}):
            self.assertEqual(policy.count_text("abc"), 2)
        policy._tokenizer.cache_clear()

    def test_json_accepts_fences_prose_and_thinking(self):
        for text in ('{"ok": true}', '```json\n{"ok": true}\n```', '<think>reasoning</think>\n{"ok": true}', 'Result: {"ok": true}'):
            self.assertEqual(policy.parse_json(text), {"ok": True})

    def test_json_rejects_tuples_and_invalid_outer_object(self):
        for text in ('{"x": (1, 2)}', '{"x": [], broken}', '{"x": NaN}', 'no json', '__import__("os")'):
            with self.assertRaises(ValueError): policy.parse_json(text)

    def test_preserves_initial_source_latest_turn_and_tool_groups(self):
        source = HumanMessage("source")
        old = HumanMessage("old")
        latest = HumanMessage("latest")
        group = [AIMessage("x" * 7800, tool_calls=[{"name": "tool"}]), ToolMessage("result")]
        result = policy.fit_messages([SystemMessage("rules"), source, old] + group + [latest])
        self.assertEqual([m.content for m in result], ["rules", "source", "latest"])

    def test_oversize_source_is_rejected_not_truncated(self):
        with self.assertRaises(policy.ContextBudgetError):
            policy.fit_messages([HumanMessage("x" * 9000)])

    def test_metadata_not_required_for_tools(self):
        msg = AIMessage("", tool_calls=[{"name": "probe", "args": {}}])
        self.assertGreater(policy.message_tokens(msg), 0)

    def test_adapter_clamps_and_supports_string_input(self):
        client = Client()
        value = policy.LocalChatAdapter(client, schema=Schema).invoke("task", max_tokens=64000)
        self.assertEqual(value, {"ok": True})
        self.assertEqual(client.calls[0][1]["max_tokens"], 512)

    def test_invalid_json_corrected_with_bounded_retry(self):
        client = Client([AIMessage("bad"), AIMessage('{"ok": true}')])
        self.assertEqual(policy.LocalChatAdapter(client, schema=Schema).invoke([HumanMessage("task")]), {"ok": True})
        self.assertEqual(len(client.calls), 2)

    def test_invalid_json_stops_at_configured_limit(self):
        client = Client([AIMessage("bad")] * 3)
        with self.assertRaises(policy.LocalModelError):
            policy.LocalChatAdapter(client, schema=Schema).invoke([HumanMessage("task")])
        self.assertEqual(len(client.calls), 3)

    def test_permanent_request_error_is_not_retried(self):
        client = Client([ValueError("unsupported parameter")])
        with self.assertRaises(policy.LocalModelError):
            policy.LocalChatAdapter(client).invoke([HumanMessage("task")])
        self.assertEqual(len(client.calls), 1)

    def test_transient_retries_stop(self):
        class APIConnectionError(Exception): pass
        client = Client([APIConnectionError("offline")] * 3)
        with patch.object(policy.time, "sleep"):
            with self.assertRaises(policy.LocalModelError):
                policy.LocalChatAdapter(client).invoke([HumanMessage("task")])
        self.assertEqual(len(client.calls), 3)

    def test_truncated_response_is_not_presented_as_success(self):
        client = Client([AIMessage('{"ok": true}', response_metadata={"finish_reason": "length"})])
        with self.assertRaises(policy.LocalModelError):
            policy.LocalChatAdapter(client, schema=Schema).invoke([HumanMessage("task")])

    def test_sync_concurrency_across_threads(self):
        active = peak = 0
        lock = threading.Lock()
        class Slow:
            def invoke(self, messages, **kwargs):
                nonlocal active, peak
                with lock:
                    active += 1
                    peak = max(peak, active)
                time.sleep(0.025)
                with lock: active -= 1
                return AIMessage("done")
        adapter = policy.LocalChatAdapter(Slow())
        threads = [threading.Thread(target=adapter.invoke, args=([HumanMessage("task")],)) for _ in range(8)]
        for t in threads: t.start()
        for t in threads: t.join()
        self.assertEqual(peak, 2)

    def test_async_concurrency_and_cancellation_release(self):
        async def run():
            active = peak = 0
            class Slow:
                async def ainvoke(self, messages, **kwargs):
                    nonlocal active, peak
                    active += 1
                    peak = max(peak, active)
                    try: await asyncio.sleep(0.025)
                    finally: active -= 1
                    return AIMessage("done")
            adapter = policy.LocalChatAdapter(Slow())
            await asyncio.gather(*(adapter.ainvoke([HumanMessage("task")]) for _ in range(8)))
            self.assertEqual(peak, 2)
            task = asyncio.create_task(adapter.ainvoke([HumanMessage("task")]))
            await asyncio.sleep(0.005)
            task.cancel()
            with self.assertRaises(asyncio.CancelledError): await task
            await adapter.ainvoke([HumanMessage("task")])
            self.assertTrue(policy._gate().acquire(blocking=False))
            self.assertTrue(policy._gate().acquire(blocking=False))
            policy._gate().release(); policy._gate().release()
        asyncio.run(run())

    def test_async_json_correction(self):
        client = Client([AIMessage("bad"), AIMessage('{"ok": true}')])
        result = asyncio.run(policy.LocalChatAdapter(client, schema=Schema).ainvoke([HumanMessage("task")]))
        self.assertEqual(result, {"ok": True})


class ArtifactTests(unittest.TestCase):
    def test_manifest_hashes_and_python_syntax(self):
        for entry in json.loads((ROOT / "manifest.json").read_text()):
            path = ROOT / entry["replacement"]
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), entry["replacement_sha256"])
            if path.suffix == ".py": ast.parse(path.read_text(), filename=str(path))

    def test_prompt_example_is_valid_after_template_expansion(self):
        path = ROOT / "updated-files/atlantis/blob-gen/multilang-llm-agent/mlla/prompts/mcga.py"
        tree = ast.parse(path.read_text())
        string = next(n.value for n in ast.walk(tree) if isinstance(n, ast.Constant) and isinstance(n.value, str) and "<output_format>" in n.value)
        snippet = string.split("<output_format>")[1].split("</output_format>")[0].replace("{{", "{").replace("}}", "}")
        self.assertIs(json.loads(snippet)["is_vulnerable"], False)


class IntegrationTests(unittest.TestCase):
    setUp = PolicyTests.setUp
    tearDown = PolicyTests.tearDown
    def test_actual_llm_constructor_uses_only_local_openai_clients(self):
        path = ROOT / "updated-files/atlantis/blob-gen/multilang-llm-agent/mlla/utils/llm.py"
        tree = ast.parse(path.read_text())
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "LLM")
        node = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "__init__")
        for arg in node.args.args + node.args.kwonlyargs: arg.annotation = None
        node.returns = None
        calls = []
        class FakeOpenAI:
            def __init__(self, **kwargs): calls.append(kwargs)
            def bind_tools(self, tools): return self
        def forbidden(*args, **kwargs): raise AssertionError("Hosted-model client/router reached")
        namespace = dict(local_stack=policy, ChatOpenAI=FakeOpenAI, ChatAnthropic=forbidden,
            set_chat_litellm_router=forbidden, AgentSpecificCallback=lambda *x: object(),
            get_agent_instance_context=lambda: None)
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec"), namespace)
        context = types.SimpleNamespace(global_rate_limiter=None, global_claude_rate_limiter=None,
            general_callback=None, api_key="test-key", base_url="http://example.invalid/v1",
            openai_timeout=120, openai_max_retries=5)
        for alias in ("claude-sonnet-4-6", "atlanta", "gemini-3.1-pro-preview", "gemma4"):
            obj = types.SimpleNamespace()
            namespace["__init__"](obj, alias, context, agent_name="test", max_tokens=64000)
            self.assertEqual(obj.model_name, "gemma4")
            self.assertIsInstance(obj.runnable_chat_model, policy.LocalChatAdapter)
            self.assertEqual(obj.runnable_chat_model.max_tokens, 512)
        self.assertTrue(all(c["model"] == "gemma4" for c in calls))
        self.assertTrue(all(c["max_retries"] == 0 for c in calls[::2]))

    def test_actual_mcga_validation_failure_exits_after_three_attempts(self):
        path = ROOT / "updated-files/atlantis/blob-gen/multilang-llm-agent/mlla/agents/mcga.py"
        tree = ast.parse(path.read_text())
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "MakeCallGraphAgent")
        node = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "_handle_step1_response")
        for arg in node.args.args: arg.annotation = None
        node.returns = None
        namespace = dict(local_stack=policy, MakeCallGraphOverallState=dict,
                         logger=types.SimpleNamespace(error=lambda *args: None))
        exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec"), namespace)
        async def verify(state): return state, {}, None, {}
        obj = types.SimpleNamespace(_verify_step1_response=verify, target_fn=("function",))
        async def run():
            result = None
            for _ in range(3):
                result = await namespace["_handle_step1_response"](obj, {"resolved": {"step1": False}})
            self.assertTrue(result["resolved"]["step1"])
            self.assertIsNone(result["cg_root_node"])
            self.assertFalse(result["done"])
        asyncio.run(run())

    def test_actual_cpua_failure_routes_to_finalize(self):
        path = ROOT / "updated-files/atlantis/blob-gen/multilang-llm-agent/mlla/agents/cpua.py"
        tree = ast.parse(path.read_text())
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "CPUnderstandAgent")
        names = ("_local_retry_exhausted", "switch_u_reflection", "switch_get_file_path")
        nodes = [n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name in names]
        for node in nodes:
            node.decorator_list = []
            node.returns = None
            for arg in node.args.args: arg.annotation = None
            node.body = [n for n in node.body if not isinstance(n, ast.ImportFrom)]
        namespace = dict(local_stack=policy, TOOL_MODEL="model", logger=types.SimpleNamespace(error=lambda *args: None))
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec"), namespace)
        obj = types.SimpleNamespace()
        state = {"step": 1, "resolved": {}, "api_dict": {}, "reflection_api_dict": {}, "messages": [AIMessage("bad")]}
        self.assertFalse(namespace["_local_retry_exhausted"](obj, state))
        self.assertFalse(namespace["_local_retry_exhausted"](obj, state))
        self.assertTrue(namespace["_local_retry_exhausted"](obj, state))
        self.assertEqual(namespace["switch_u_reflection"](state), "finalize")
        self.assertEqual(namespace["switch_get_file_path"](state), "finalize")


class InstallerTests(unittest.TestCase):
    def installer(self):
        spec = importlib.util.spec_from_file_location("apply_bundle", ROOT / "tools/apply_bundle.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def populate(self, target):
        entries = json.loads((ROOT / "manifest.json").read_text())
        for entry in entries:
            if entry["original_sha256"]:
                dest = target / entry["original_relative_path"]
                dest.parent.mkdir(parents=True, exist_ok=True)
                original = ROOT / "original-files/atlantis" / entry["original_relative_path"]
                dest.write_bytes(original.read_bytes().replace(b"\r\n", b"\n"))
        return entries

    def test_installs_linux_line_endings_and_is_idempotent(self):
        module = self.installer()
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)
            entries = self.populate(target)
            self.assertEqual(module.install(target, apply=False), len(entries))
            self.assertEqual(module.install(target, apply=True), len(entries))
            self.assertEqual(module.install(target, apply=True), 0)
            self.assertTrue((target / ".gemma4-compat-backups").exists())

    def test_refuses_modified_source_before_copying_any_files(self):
        module = self.installer()
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)
            entries = self.populate(target)
            original = next(e for e in entries if e["original_sha256"])
            path = target / original["original_relative_path"]
            path.write_text(path.read_text() + "\n# machine-specific changes\n")
            with self.assertRaises(ValueError): module.install(target, apply=True)
            self.assertFalse((target / ".gemma4-compat-backups").exists())
            self.assertFalse((target / entries[0]["original_relative_path"]).exists())


if __name__ == "__main__": unittest.main(verbosity=2)
