GEMMA / GPUSTACK / LITELLM COMPATIBILITY BUNDLE
============================================

Start here. This is a candidate compatibility patch for the Atlantis source
provided in this chat, not a claim that the remote deployment has been tested.
The original Atlantis and oss-crs directories on this machine were NOT edited.

CONTENTS AND ORIGINAL LOCATIONS

  updated-files/atlantis/   Replacement/new files, preserving repository paths.
  original-files/atlantis/  Original versions of files that were changed.
  FILES-AND-LOCATIONS.csv  Every replacement and its destination in Atlantis.
  manifest.json            Original and replacement SHA-256 hashes.
  atlantis.patch           Unified patch for merging into an already changed tree.
  config/compose.yaml      Example for the supplied oss-crs version.
  config/litellm-gpustack.yaml  Model entry to merge into your existing proxy.
  tools/apply_bundle.py    Checked installer; inspection-only unless --apply.
  tools/check_stack.py     Live model/JSON/native-tools preflight for your machine.
  tools/test_bundle.py     Offline regression checks with mock model clients.

Destination rule: updated-files/atlantis/<path> belongs at <YOUR_ATLANTIS>/<path>.
The new files are marked "add" in the CSV. Keep all replacement Python files and
both local_stack.py files together. They form one change, not independent fixes.

WHAT CHANGED

* Explicit local mode routes ALL central MLLA and reverser model aliases through
  ChatOpenAI to the configured OpenAI-compatible proxy and its gemma4 alias.
  No Anthropic client, Anthropic beta headers, or hosted-model fallback in local
  mode. The reverser's coding/reasoning model list also follows the local model.
* Context/output budgets are explicit deployment settings. Every local dispatch
  counts messages and tool schemas before sending. Oversized current source is
  rejected, never silently sliced into a misleading partial function. Complete
  old middle turns may be discarded, preserving original source, system messages,
  the latest user instruction, and native tool/result pairs inside kept turns.
* Structured-only output uses JSON instructions plus strict extraction and schema
  validation, not an assumed provider-specific structured-output API. Native
  tool calls still require real backend support. Invalid JSON gets bounded
  correction attempts; no eval, tuple conversion, or invented vulnerability data.
* Fixed malformed MCGA JSON example. MCGA and CPUA validation failures stop after
  the configured number of attempts and leave the analysis unresolved. CGPA,
  CPUA, MCGA, and backward call-graph JSON extraction accept fences/prose/thinking
  wrappers around otherwise valid JSON.
* Local requests have finite retry counts, explicit timeouts, output truncation
  detection, and real in-flight concurrency control across threads/event loops
  within each Python process. SDK retries are disabled for the central local
  clients so they do not multiply the configured retry budget.
* Missing token usage on tool responses no longer causes the identified counter
  crash. Tool result size checks use the local counting/budget policy.
* Dictionary generation now yields during retry waits and closes its HTTP client.
  Its local requests also use output/context limits and the in-flight gate.
* Explicit environment controls disable the generic Atlantis spending check,
  the first generator's overall timer, the outer MLLA process timer, and the
  finite MLLA invocation count. MLLA subprocess failures are logged instead of
  silently discarding their status.
* Required-model metadata now requests gemma4, not the original hosted models.
* Optional tokenizer build assets and the standalone query helper are included.

WHAT YOU STILL MUST SET FOR YOUR DEPLOYMENT

1. A LiteLLM alias named gemma4, routing to the EXACT GPUStack model ID.
   The name "gemma4" in this bundle is an alias, not a guessed model identifier.
2. The proxy URL and key. URL must end in /v1 and be reachable from containers.
   localhost inside a container is not the other machine or its host service.
3. The ACTUAL configured context length and supported maximum output length.
   32768 context / 4096 output / 2048 buffer are conservative example settings;
   they are not discovered Gemma capabilities. Never exceed the server's limits.
4. The deployed tokenizer.json if you want Gemma text token counts. A tokenizer
   cannot be reliably inferred from a proxy alias or manufactured from this repo.
5. A GPUStack inference backend/chat template/tool parser that emits native
   OpenAI-style tool_calls and accepts tool-role results. Prompt changes cannot
   add this server capability. Run the supplied live preflight before fuzzing.

TOKENIZER SETUP

Copy tokenizer.json from the EXACT deployed model/version into:

  <YOUR_ATLANTIS>/local-stack-assets/tokenizer.json

Then uncomment this in compose additional_env:

  LOCAL_LLM_TOKENIZER_JSON: /opt/local-stack-assets/tokenizer.json

Run prepare again after adding it: the updated Dockerfile copies that directory
into the runner image. The original dependencies already include tokenizers.
If your tokenizer JSON requires a newer tokenizers version, update that dependency
in your own build and rerun validation. An explicit bad/incompatible tokenizer
file causes a clear error instead of silently changing tokenizers.

Without the file, the code warns once per process and uses UTF-8 byte length as
a conservative text estimate. That estimate is NOT the Gemma tokenizer. Even
with tokenizer.json, role/chat-template formatting is estimated and the token
buffer remains necessary; this is not an exact server chat-template token count.

INSTALLING ON YOUR OTHER MACHINE

Extract the complete bundle. Use Python 3.11+ (the Atlantis runtime version).
Examples assume sibling oss-crs, Atlantis, and gemma4-compatibility directories.

First inspect against your existing Atlantis checkout (does not modify it):

  python3 gemma4-compatibility/tools/apply_bundle.py \
    --atlantis /absolute/path/to/atlantis

If every file matches the reviewed base, apply with:

  python3 gemma4-compatibility/tools/apply_bundle.py \
    --atlantis /absolute/path/to/atlantis --apply

The installer makes backups under Atlantis/.gemma4-compat-backups/ and refuses
the WHOLE copy if it finds an existing edit or unexpected file. It accepts
equivalent LF/CRLF originals. It does not overwrite modified files by force.

Because your other machine already has changes, conflicts are expected. In
that case, merge the patch into that checkout instead of copying over your work:

  cd /absolute/path/to/atlantis
  git apply --check /absolute/path/to/gemma4-compatibility/atlantis.patch
  git apply /absolute/path/to/gemma4-compatibility/atlantis.patch

Run the second command only when the check passes. If it fails, merge the
affected hunks manually using original-files/ and updated-files/ as references.
Do not reset the repository or delete workdirs/Redis data to apply this bundle.

CONFIGURATION AND RUN

The provided config/compose.yaml uses the CURRENT schema in the supplied
oss-crs-main checkout. It is intended as the replacement/example content for:

  <YOUR_OSS_CRS>/example/atlantis-multilang-wo-concolic/compose.yaml

Keep existing CPU/memory settings if your machine differs. Edit source.local_path
to point at the PATCHED LOCAL Atlantis checkout. Otherwise prepare may build a
registry/downloaded source instead, and your changes will not be in the image.
Relative source paths are interpreted from the directory where oss-crs runs.

The LiteLLM example is a MERGE SNIPPET for your existing proxy configuration,
not a replacement for its authentication/security settings. Replace its model
placeholder with the real GPUStack model ID. Set GPUSTACK_API_BASE (ending /v1)
and GPUSTACK_API_KEY in the proxy's environment. Keep the public alias gemma4.
If you change that alias, change both LOCAL_LLM_MODEL and oss-crs/crs.yaml's
required_llms to match.

The compose example uses external LiteLLM and does not set llm_budget.
An existing proxy/key/team budget must also allow your intended local usage;
this bundle cannot modify the other machine's proxy settings automatically.

From the oss-crs directory:

  export CUSTOM_LITELLM_URL='http://YOUR_PROXY_HOST:4000/v1'
  export CUSTOM_LITELLM_KEY='YOUR_EXISTING_PROXY_KEY'

Preflight (three small inference requests; never executes a model-generated tool):

  python3 /path/to/gemma4-compatibility/tools/check_stack.py

Then use your existing workflow with the configured compose file:

  uv run oss-crs prepare \
    --compose-file ./example/atlantis-multilang-wo-concolic/compose.yaml

  uv run oss-crs build-target \
    --compose-file ./example/atlantis-multilang-wo-concolic/compose.yaml \
    --fuzz-proj-path ./oss-fuzz/projects/libxml2

  uv run oss-crs run \
    --compose-file ./example/atlantis-multilang-wo-concolic/compose.yaml \
    --fuzz-proj-path ./oss-fuzz/projects/libxml2 \
    --target-harness xml

Use the actual built harness name. Prepare is required because this bundle
changes Rust code, Python files inside images, and Docker build inputs. A target
rebuild is included here to avoid reusing artifacts from an unknown remote build.
Do not use --timeout if you want the oss-crs run itself to have no wall-clock cap.

LIMITS THAT REMAIN INTENTIONALLY

Per-request timeouts, context/output limits, finite validation attempts, graph
step limits, and per-analysis/generator improvement limits still exist. A failed
analysis should be skipped/retried later, not spin forever. The local example
removes spending/overall MLLA invocation ceilings; it does not remove memory,
context, or individual analysis bounds. MAX_DEPTH and MCGA's per-analysis timeout
are still present. Total concurrency is the sum across Python processes; the
setting LOCAL_LLM_MAX_INFLIGHT=2 is NOT a global limit across every container.

Docker Compose's existing abort-on-container-exit behavior is unchanged.
An independent LSP crash, OOM, disk error, or infrastructure failure can still
stop the stack. This patch does not hide failed infrastructure with restarts.

VALIDATION AND LIMITATIONS

See VALIDATION.txt for actual results. Offline checks use mock model clients and
exercise parsing, budget enforcement, retries, concurrency/cancellation, selected
real wrapper/MCGA methods, and installation safeguards. They do not prove model
quality or native backend tool support. No live GPUStack/LiteLLM endpoint, Docker
image build, Rust compilation, libxml2 fuzzing run, or long soak was available on
this Windows machine. Perform the live preflight, prepare/build, and a smoke run
on your Linux machine before relying on an unattended long run.

This bundle targets the files supplied here. Merge conflicts or additional
changes on the other machine require fresh validation after merging. No promise
is made that all remote-only modifications are covered.
