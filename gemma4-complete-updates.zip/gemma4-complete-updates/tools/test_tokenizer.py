import importlib.util
import os
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / 'updated-files/atlantis/blob-gen/multilang-llm-agent/mlla/utils/local_stack.py'
spec = importlib.util.spec_from_file_location('gemma_policy', PATH)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class TokenizerTests(unittest.TestCase):
    def setUp(self):
        module._hf_tokenizer.cache_clear()
        module._tokenizer.cache_clear()
        self.env = patch.dict(os.environ, {'LOCAL_LLM_TOKENIZER_JSON': '',
            'LOCAL_LLM_TOKENIZER_MODEL': 'google/gemma-4-31B-it',
            'LOCAL_LLM_TOKENIZER_REVISION': 'main', 'LOCAL_LLM_TOKENIZER_OFFLINE': '0'})
        self.env.start()
        self.calls = []
        calls = self.calls
        class AutoTokenizer:
            @staticmethod
            def from_pretrained(model, **kwargs):
                calls.append((model, kwargs))
                return types.SimpleNamespace(encode=lambda text, add_special_tokens: [101, 202])
        self.fake = patch.dict(sys.modules, {'transformers': types.SimpleNamespace(AutoTokenizer=AutoTokenizer)})
        self.fake.start()
    def tearDown(self):
        self.fake.stop()
        self.env.stop()

    def test_loads_correct_model_and_counts_real_ids(self):
        self.assertEqual(module.count_text('hello world'), 2)
        self.assertEqual(self.calls[0][0], 'google/gemma-4-31B-it')
        self.assertIs(self.calls[0][1]['trust_remote_code'], False)

    def test_default_model_without_environment_override(self):
        with patch.dict(os.environ):
            os.environ.pop('LOCAL_LLM_TOKENIZER_MODEL')
            self.assertEqual(module.count_text('hello'), 2)
            self.assertEqual(self.calls[0][0], 'google/gemma-4-31B-it')

    def test_caches_tokenizer(self):
        module.count_text('first'); module.count_text('second')
        self.assertEqual(len(self.calls), 1)

    def test_supports_revision_and_offline_cache(self):
        with patch.dict(os.environ, {'LOCAL_LLM_TOKENIZER_REVISION': 'deployed-revision', 'LOCAL_LLM_TOKENIZER_OFFLINE': '1'}):
            module.count_text('text')
        self.assertEqual(self.calls[0][1]['revision'], 'deployed-revision')
        self.assertTrue(self.calls[0][1]['local_files_only'])

    def test_supports_existing_local_json_override(self):
        class Tokenizer:
            @staticmethod
            def from_file(path):
                return types.SimpleNamespace(encode=lambda text, add_special_tokens: types.SimpleNamespace(ids=[1,2,3]))
        with patch.dict(sys.modules, {'tokenizers': types.SimpleNamespace(Tokenizer=Tokenizer)}), patch.dict(os.environ, {'LOCAL_LLM_TOKENIZER_JSON': 'existing.json'}):
            self.assertEqual(module.count_text('text'), 3)
            self.assertEqual(self.calls, [])

    def test_load_failure_never_silently_estimates(self):
        class AutoTokenizer:
            @staticmethod
            def from_pretrained(*args, **kwargs): raise RuntimeError('offline, not cached')
        with patch.dict(sys.modules, {'transformers': types.SimpleNamespace(AutoTokenizer=AutoTokenizer)}):
            with self.assertRaisesRegex(module.LocalModelError, 'No byte-count/GPT-tokenizer fallback'):
                module.count_text('text')

    def test_both_helpers_identical(self):
        other = ROOT / 'updated-files/atlantis/dictgen/src/utility/local_stack.py'
        self.assertEqual(PATH.read_bytes(), other.read_bytes())

    def test_requirements_include_compatible_tokenizer_dependencies(self):
        for path in ('blob-gen/multilang-llm-agent/requirements_docker.txt', 'dictgen/requirements.txt'):
            text = (ROOT / 'updated-files/atlantis' / path).read_text()
            for line in ('transformers==5.5.3', 'tokenizers>=0.22.0,<=0.23.0', 'huggingface-hub>=1.5.0,<2.0', 'regex>=2025.10.22'):
                self.assertIn(line, text)


if __name__ == '__main__': unittest.main(verbosity=2)
