"""Explicit network preflight against the user's proxy; never prints API keys."""
import argparse
import json
import os
from pathlib import Path
import sys
import urllib.request
import urllib.error
import importlib.util

spec = importlib.util.spec_from_file_location("local_stack", Path(__file__).with_name("local_stack.py"))
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)


def request(base, key, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(base.rstrip("/") + path, data=data,
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=int(os.getenv("LOCAL_LLM_TIMEOUT", "300"))) as response:
        return json.load(response)


def check(base, key, model):
    models = request(base, key, "/models")
    if model not in [m["id"] for m in models.get("data", [])]:
        raise ValueError(f"Proxy does not advertise model alias {model!r}")
    result = request(base, key, "/chat/completions", {"model": model, "max_tokens": 256,
        "temperature": 0, "messages": [{"role": "system", "content": "Return strict JSON when requested."},
        {"role": "user", "content": 'Return only this JSON object: {"ok": true}'}]})
    choice = result["choices"][0]
    if choice.get("finish_reason") == "length":
        raise ValueError("JSON probe was truncated; check reasoning/output configuration")
    if policy.parse_json(choice["message"].get("content")) != {"ok": True}:
        raise ValueError("JSON probe did not match the requested object")
    tool = {"type": "function", "function": {"name": "compatibility_probe",
        "description": "Return the supplied integer", "parameters": {"type": "object",
        "properties": {"value": {"type": "integer"}}, "required": ["value"]}}}
    result = request(base, key, "/chat/completions", {"model": model, "max_tokens": 512,
        "temperature": 0, "tools": [tool], "messages": [{"role": "user",
        "content": "Call compatibility_probe with value 7 using a native tool call. Do not answer in prose."}]})
    calls = result["choices"][0]["message"].get("tool_calls", [])
    if not calls or calls[0]["function"]["name"] != "compatibility_probe":
        raise ValueError("Native tool call missing. Configure the GPUStack inference backend's tool parser/chat template; Atlantis needs native tools.")
    arguments = calls[0]["function"]["arguments"]
    if (json.loads(arguments) if isinstance(arguments, str) else arguments) != {"value": 7}:
        raise ValueError("Native tool arguments are invalid")
    result = request(base, key, "/chat/completions", {"model": model, "max_tokens": 256,
        "temperature": 0, "tools": [tool], "messages": [
        {"role": "user", "content": "Call compatibility_probe with value 7, then return only the tool result as JSON."},
        {k: v for k, v in result["choices"][0]["message"].items() if k in ("role", "content", "tool_calls")},
        {"role": "tool", "tool_call_id": calls[0]["id"], "content": '{"value": 7}'}]})
    if policy.parse_json(result["choices"][0]["message"].get("content")) != {"value": 7}:
        raise ValueError("Tool-result round trip did not produce the requested JSON")
    print("PASS: model alias, system role, JSON generation, native tool arguments and tool-result round trip")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default=os.getenv("LOCAL_LLM_MODEL", "gemma4"))
    args = parser.parse_args()
    base = os.getenv("CUSTOM_LITELLM_URL", os.getenv("LITELLM_URL", ""))
    key = os.getenv("CUSTOM_LITELLM_KEY", os.getenv("LITELLM_KEY", ""))
    if not base or not key:
        parser.error("Set CUSTOM_LITELLM_URL (ending in /v1) and CUSTOM_LITELLM_KEY")
    try: check(base, key, args.model)
    except Exception as exc:
        print("FAIL: " + str(exc).replace(key, "[redacted]"), file=sys.stderr)
        sys.exit(1)
