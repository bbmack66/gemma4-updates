Optional: put the tokenizer.json from the exact deployed Gemma model here before prepare.
Then set LOCAL_LLM_TOKENIZER_JSON=/opt/local-stack-assets/tokenizer.json in compose additional_env.
This file is a container build input; do not put API keys here.
