"""Local-model client shared by Atlantis agents. No hosted-provider routing."""
import dataclasses
import inspect
from copy import deepcopy
from typing import Callable, Optional, TypeVar

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, RemoveMessage, SystemMessage
from langchain_core.tools.base import BaseTool
from langchain_openai import ChatOpenAI
from loguru import logger

from ..prompts.llm import ASK_AND_REPEAT_UNTIL_MSG, TOOL_DESC
from . import local_stack
from .agent_context import get_agent_instance_context, get_agent_name_from_instance
from .autoprompt import AutoPromptChoice, generate_prompt
from .bedrock_callback import AgentSpecificCallback
from .code_tags import END_TOOLS_TAG, TOOLS_TAG
from .context import GlobalContext

T = TypeVar("T")


@dataclasses.dataclass
class PrioritizedTool:
    priority: int
    _tool: BaseTool

    @staticmethod
    def from_tool(tool: BaseTool, priority: int) -> "PrioritizedTool":
        return PrioritizedTool(priority=priority, _tool=tool)

    @staticmethod
    def from_tools(tools: list[BaseTool], priority: list[int] | int) -> list["PrioritizedTool"]:
        priorities = [priority] * len(tools) if isinstance(priority, int) else list(priority)
        if len(priorities) != len(tools):
            raise ValueError("Each tool must have a priority")
        return [PrioritizedTool.from_tool(tool, value) for tool, value in zip(tools, priorities)]

    def get_tool(self) -> BaseTool:
        return self._tool


class LLM:
    """Use only the configured OpenAI-compatible local inference endpoint."""

    def __init__(self, model: str, config: GlobalContext,
                 tools: list[PrioritizedTool] | None = None, output_format=None,
                 temperature=0, max_tokens: Optional[int] = None,
                 concurrent_limit: Optional[int] = None, prompt_caching: bool = False,
                 agent_name: Optional[str] = None, prepare_large_context_model: bool = False):
        # Older callers can still supply caching/fallback keywords. They never
        # select another provider; the adapter owns the shared concurrency limit.
        self.gc = config
        self.tools = list(tools or [])
        self.model_name = local_stack.model_name(model)
        self.agent_name = agent_name or get_agent_name_from_instance() or ""
        self.instance_id = get_agent_instance_context()
        self.callbacks = ([AgentSpecificCallback(self.agent_name, config.general_callback)]
                          if self.agent_name else [config.general_callback])
        max_tokens = local_stack.output_limit(max_tokens)
        self.chat_model = ChatOpenAI(
            model=self.model_name, temperature=temperature, api_key=config.api_key,
            base_url=config.base_url, timeout=local_stack.setting("LOCAL_LLM_TIMEOUT", 300),
            max_retries=0, max_tokens=max_tokens, callbacks=self.callbacks,
        )
        client = self.chat_model
        raw_tools = [tool.get_tool() for tool in self.tools]
        if raw_tools:
            client = client.bind_tools(raw_tools)
        self.runnable_chat_model = local_stack.LocalChatAdapter(
            client, schema=output_format, tools=raw_tools, max_tokens=max_tokens)

    def get_context_limit(self) -> int:
        return (local_stack.context_size() - local_stack.output_limit()
                - local_stack.setting("LOCAL_LLM_TOKEN_BUFFER", 2048))

    def get_output_limit(self) -> int:
        return local_stack.output_limit()

    def tokenize(self, messages: list[BaseMessage]) -> list[tuple[int, BaseMessage]]:
        return [(0 if isinstance(m, RemoveMessage) else local_stack.message_tokens(m), m) for m in messages]

    def summarize(self, messages: list[BaseMessage]) -> list[BaseMessage]:
        # Keep the original source; never switch to a supposed larger model.
        return local_stack.fit_messages(messages, tools=[t.get_tool() for t in self.tools])

    def _add_tools_desc(self, messages: list[BaseMessage]) -> list[BaseMessage]:
        if TOOLS_TAG in messages[0].content:
            return messages
        description = TOOL_DESC + TOOLS_TAG + "\n"
        for tool in sorted(self.tools, key=lambda item: item.priority, reverse=True):
            description += f"{tool.get_tool().name}: {tool.get_tool().description}\n"
        messages[0].content += "\n" + description + END_TOOLS_TAG
        return messages

    def first_human_msg_to_system_msg(self, messages: list[BaseMessage]) -> list[BaseMessage]:
        if messages and isinstance(messages[0], HumanMessage):
            first = messages[0]
            messages[0] = SystemMessage(content=first.content, id=first.id)
        return messages

    def _prepare_messages(self, messages, choice, cache=None):
        if self.tools and len({tool.priority for tool in self.tools}) > 1:
            messages = self._add_tools_desc(messages)
        messages = self.first_human_msg_to_system_msg(messages)
        messages = generate_prompt(messages, self.gc, choice)
        removed = [m for m in messages if isinstance(m, RemoveMessage)]
        messages = [m for m in messages if not isinstance(m, RemoveMessage)]
        previous = messages
        messages = self.summarize(messages)
        kept = {m.id for m in messages if getattr(m, "id", None)}
        removed += [RemoveMessage(id=m.id) for m in previous
                    if getattr(m, "id", None) and m.id not in kept]
        for message in messages:
            if isinstance(message.content, str):
                message.content = inspect.cleandoc(message.content)
        return messages, removed

    def invoke(self, messages: list[BaseMessage],
               choice: AutoPromptChoice | list[AutoPromptChoice] = AutoPromptChoice.NOCHANGE,
               cache=None, cache_index=0, force_large_model=False, large_model_callback=None,
               **kwargs) -> list[BaseMessage]:
        if not messages:
            raise local_stack.LocalModelError("Cannot invoke local model without messages")
        copied = deepcopy(messages)
        if isinstance(copied[-1], AIMessage) and copied[-1].tool_calls:
            choice = AutoPromptChoice.NOCHANGE
        prepared, removed = self._prepare_messages(copied, choice)
        response = self.runnable_chat_model.invoke(prepared, **kwargs)
        return prepared + removed + [response]

    async def ainvoke(self, messages: list[BaseMessage],
                      choice: AutoPromptChoice | list[AutoPromptChoice] = AutoPromptChoice.NOCHANGE,
                      cache=None, cache_index=0, force_large_model=False, large_model_callback=None,
                      **kwargs) -> list[BaseMessage]:
        if not messages:
            raise local_stack.LocalModelError("Cannot invoke local model without messages")
        copied = deepcopy(messages)
        if isinstance(copied[-1], AIMessage) and copied[-1].tool_calls:
            choice = AutoPromptChoice.NOCHANGE
        prepared, removed = self._prepare_messages(copied, choice)
        response = await self.runnable_chat_model.ainvoke(prepared, **kwargs)
        return prepared + removed + [response]

    def _get_model_settings(self) -> tuple[int, int]:
        return (local_stack.setting("LOCAL_LLM_TIMEOUT", 300),
                local_stack.setting("LOCAL_LLM_VALIDATION_ATTEMPTS", 3))

    def ask_and_repeat_until(self, verifier: Callable[..., T], messages: list, default: T,
                             recoverer: Optional[Callable[..., T]] = None,
                             max_retries: Optional[int] = None, try_with_error=True,
                             pass_retries_to_verifier=False, cache=False, cache_index=0) -> T:
        attempts = max_retries if max_retries is not None else self._get_model_settings()[1]
        copied, response = deepcopy(messages), None
        for attempt in range(attempts):
            try:
                response = self.invoke(copied)[-1]
                return verifier(response, attempts - attempt - 1) if pass_retries_to_verifier else verifier(response)
            except Exception as exc:
                logger.warning("Local analysis attempt {}/{} failed: {}", attempt + 1, attempts, exc)
                if try_with_error:
                    if isinstance(response, BaseMessage): copied.append(response)
                    copied.append(HumanMessage(ASK_AND_REPEAT_UNTIL_MSG.format(e=exc)))
        if response is not None and recoverer is not None:
            try: return recoverer(response)
            except Exception: pass
        return default

    async def aask_and_repeat_until(self, verifier: Callable[..., T], messages: list, default: T,
                                    recoverer: Optional[Callable[..., T]] = None,
                                    max_retries: Optional[int] = None, try_with_error=True,
                                    pass_retries_to_verifier=False, cache=False, cache_index=0) -> T:
        attempts = max_retries if max_retries is not None else self._get_model_settings()[1]
        copied, response = deepcopy(messages), None
        for attempt in range(attempts):
            try:
                response = (await self.ainvoke(copied))[-1]
                return verifier(response, attempts - attempt - 1) if pass_retries_to_verifier else verifier(response)
            except Exception as exc:
                logger.warning("Local analysis attempt {}/{} failed: {}", attempt + 1, attempts, exc)
                if try_with_error:
                    if isinstance(response, BaseMessage): copied.append(response)
                    copied.append(HumanMessage(ASK_AND_REPEAT_UNTIL_MSG.format(e=exc)))
        if response is not None and recoverer is not None:
            try: return recoverer(response)
            except Exception: pass
        return default
