"""Local model identity; hosted-provider routing tables have been removed."""
from .local_stack import model_name

LOCAL_MODEL = model_name("")
