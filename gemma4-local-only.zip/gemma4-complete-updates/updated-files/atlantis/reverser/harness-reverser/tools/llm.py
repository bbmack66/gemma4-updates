"""OpenAI-compatible local inference client for the harness reverser."""
from langchain_openai import ChatOpenAI
from mlla.utils import local_stack


class LLM:
    def __init__(self, model, config, tools=None, output_format=None,
                 temperature=0, max_tokens=None, model_kwargs=None):
        if tools and output_format is not None:
            raise ValueError("Use either native tools or structured output")
        self.model_name = local_stack.model_name(model)
        self.gc = config
        max_tokens = local_stack.output_limit(max_tokens)
        self.chat_model = ChatOpenAI(
            model=self.model_name, temperature=temperature,
            api_key=config.api_key, base_url=config.base_url,
            max_tokens=max_tokens, timeout=local_stack.setting("LOCAL_LLM_TIMEOUT", 300),
            max_retries=0,
        )
        client = self.chat_model.bind_tools(tools) if tools else self.chat_model
        self.runnable_chat_model = local_stack.LocalChatAdapter(
            client, schema=output_format, tools=tools or (), max_tokens=max_tokens)

    def invoke(self, messages, **kwargs):
        return messages + [self.runnable_chat_model.invoke(messages, **kwargs)]

    async def ainvoke(self, messages, max_tokens=None, **kwargs):
        if max_tokens is not None:
            kwargs["max_tokens"] = local_stack.output_limit(max_tokens)
        return messages + [await self.runnable_chat_model.ainvoke(messages, **kwargs)]
