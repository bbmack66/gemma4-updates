import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from test_bundle import InstallerTests, ROOT


class CleanupTests(unittest.TestCase):
    def test_no_asset_copy_or_unrelated_query_replacement(self):
        entries = json.loads((ROOT / 'manifest.json').read_text())
        paths = {e['original_relative_path'] for e in entries}
        self.assertNotIn('local-stack-assets/README.txt', paths)
        self.assertNotIn('scripts/query-llm.py', paths)
        docker = ROOT / 'updated-files/atlantis/oss-crs/dockerfiles/multilang-base-runner.Dockerfile'
        self.assertNotIn('local-stack-assets', docker.read_text())

    def test_known_obsolete_note_is_backed_up_before_removal(self):
        installer = InstallerTests().installer()
        content = ('Optional: put the tokenizer.json from the exact deployed Gemma model here before prepare.\n'
            'Then set LOCAL_LLM_TOKENIZER_JSON=/opt/local-stack-assets/tokenizer.json in compose additional_env.\n'
            'This file is a container build input; do not put API keys here.\n').encode()
        known = json.loads((ROOT / 'cleanup-obsolete.json').read_text())[0]['known_sha256']
        self.assertIn(hashlib.sha256(content).hexdigest(), known)
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary)
            InstallerTests().populate(target)
            old = target / 'local-stack-assets/README.txt'
            old.parent.mkdir()
            old.write_bytes(content)
            installer.install(target, apply=True)
            self.assertFalse(old.exists())
            backup = next((target / '.gemma4-compat-backups').iterdir())
            self.assertEqual((backup / 'local-stack-assets/README.txt').read_bytes(), content)
            self.assertEqual(installer.install(target, apply=True), 0)

    def test_custom_asset_note_is_preserved(self):
        installer = InstallerTests().installer()
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary)
            InstallerTests().populate(target)
            custom = target / 'local-stack-assets/README.txt'
            custom.parent.mkdir()
            custom.write_text('My own notes')
            installer.install(target, apply=True)
            self.assertEqual(custom.read_text(), 'My own notes')


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CleanupTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())
