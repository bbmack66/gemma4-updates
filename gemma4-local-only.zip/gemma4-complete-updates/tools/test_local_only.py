import ast
from copy import deepcopy
import inspect
import json
import os
from pathlib import Path
import types
import unittest
from unittest.mock import patch
import asyncio

from test_bundle import (ROOT, policy, PolicyTests, Message, HumanMessage,
                         SystemMessage, AIMessage, ToolMessage)


class RemoveMessage(Message):
    type = 'remove'


class LocalOnlyTests(unittest.TestCase):
    setUp = PolicyTests.setUp
    tearDown = PolicyTests.tearDown

    def client_class(self, path):
        tree = ast.parse((ROOT / 'updated-files/atlantis' / path).read_text(encoding='utf-8'))
        node = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'LLM')
        class StripAnnotations(ast.NodeTransformer):
            def visit_arg(self, arg): arg.annotation = None; return arg
            def visit_FunctionDef(self, value):
                value = self.generic_visit(value); value.returns = None; return value
            def visit_AsyncFunctionDef(self, value):
                value = self.generic_visit(value); value.returns = None; return value
        node = StripAnnotations().visit(node)
        self.created, self.requests = [], []
        created, requests = self.created, self.requests
        class FakeOpenAI:
            def __init__(self, **kwargs): created.append(kwargs)
            def bind_tools(self, tools): return self
            def invoke(self, messages, **kwargs):
                requests.append((messages, kwargs))
                return AIMessage('response')
            async def ainvoke(self, messages, **kwargs): return self.invoke(messages, **kwargs)
        ns = dict(local_stack=policy, ChatOpenAI=FakeOpenAI, deepcopy=deepcopy,
            get_agent_name_from_instance=lambda: '', get_agent_instance_context=lambda: None,
            AgentSpecificCallback=lambda *args: None, BaseMessage=Message,
            HumanMessage=HumanMessage, AIMessage=AIMessage, SystemMessage=SystemMessage,
            RemoveMessage=RemoveMessage, inspect=inspect,
            AutoPromptChoice=types.SimpleNamespace(NOCHANGE='nochange'),
            generate_prompt=lambda messages, config, choice: messages,
            logger=types.SimpleNamespace(warning=lambda *args: None),
            ASK_AND_REPEAT_UNTIL_MSG='{e}')
        exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(path),'exec'),ns)
        return ns['LLM']

    def context(self):
        return types.SimpleNamespace(api_key='test-key',base_url='http://example.invalid/v1',general_callback=None)

    def test_no_hosted_clients_or_local_mode_switch_in_shipped_runtime(self):
        for entry in json.loads((ROOT/'manifest.json').read_text()):
            path = ROOT/entry['replacement']
            if path.suffix != '.py': continue
            text = path.read_text(encoding='utf-8')
            for forbidden in ('ChatAnthropic','langchain_anthropic','anthropic.BadRequestError',
                              'local_stack.enabled(', 'LOCAL_LLM_ENABLED'):
                self.assertNotIn(forbidden,text,str(path))
        self.assertFalse(hasattr(policy,'enabled'))

    def test_sync_request_stays_local_with_old_flag_disabled(self):
        cls = self.client_class('blob-gen/multilang-llm-agent/mlla/utils/llm.py')
        with patch.dict(os.environ,{'LOCAL_LLM_ENABLED':'0'}):
            client = cls('old-provider-alias',self.context())
            out = client.invoke([SystemMessage('rules'),HumanMessage('task')],force_large_model=True,cache=True)
        self.assertEqual(out[-1].content,'response')
        self.assertEqual(len(self.created),1)
        self.assertEqual(self.created[0]['model'],'gemma4')
        self.assertEqual(self.created[0]['base_url'],'http://example.invalid/v1')
        self.assertEqual(len(self.requests),1)

    def test_async_request_uses_same_local_client(self):
        cls = self.client_class('blob-gen/multilang-llm-agent/mlla/utils/llm.py')
        client = cls('old-provider-alias',self.context())
        result = asyncio.run(client.ainvoke([SystemMessage('rules'),HumanMessage('task')]))
        self.assertEqual(result[-1].content,'response')
        self.assertEqual(len(self.created),1)
        self.assertEqual(len(self.requests),1)

    def test_validation_exhaustion_returns_unresolved_default(self):
        cls = self.client_class('blob-gen/multilang-llm-agent/mlla/utils/llm.py')
        client = cls('old-provider-alias',self.context())
        def invalid(response): raise ValueError('bad report')
        unresolved=object()
        self.assertIs(client.ask_and_repeat_until(invalid,[SystemMessage('rules'),HumanMessage('source')],unresolved),unresolved)
        self.assertEqual(len(self.requests),3)

    def test_oversized_current_source_is_rejected_without_request(self):
        cls = self.client_class('blob-gen/multilang-llm-agent/mlla/utils/llm.py')
        client = cls('old-provider-alias',self.context())
        with self.assertRaises(policy.ContextBudgetError):
            client.invoke([SystemMessage('rules'),HumanMessage('x'*10000)])
        self.assertEqual(self.requests,[])

    def test_reverser_uses_only_openai_compatible_local_transport(self):
        cls = self.client_class('reverser/harness-reverser/tools/llm.py')
        client=cls('old-provider-alias',self.context())
        self.assertEqual(client.invoke([HumanMessage('task')])[-1].content,'response')
        self.assertEqual(self.created[0]['model'],'gemma4')
        self.assertEqual(self.created[0]['max_retries'],0)

    def test_local_run_has_no_default_process_timer_or_spending_gate(self):
        rust=(ROOT/'updated-files/atlantis/uniafl/src/msa/stage/mlla.rs').read_text()
        self.assertIn('unwrap_or_else(|_| "0".to_string())',rust)
        self.assertIn('map(|value| value != "0").unwrap_or(true)',rust)
        tree=ast.parse((ROOT/'updated-files/atlantis/libs/libCRS/libCRS/crs.py').read_text())
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CRS')
        method=next(n for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='async_in_llm_limit')
        returns=[n for n in ast.walk(method) if isinstance(n,ast.Return)]
        self.assertEqual(len(returns),1)
        self.assertIs(returns[0].value.value,True)


if __name__ == '__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(LocalOnlyTests))
    raise SystemExit(not result.wasSuccessful())
